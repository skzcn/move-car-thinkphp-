<?php
return [
    'amap' => [
        'js_api_key' => 'd71b625cbf8b11f44194ce287624a2e9', // 高德地图 JS API Key
        'security_code' => '2c28be0e41087f2ce894ce490acc035f', // 高德地图安全密钥 (JS API 2.0 必须)
    ],
];
