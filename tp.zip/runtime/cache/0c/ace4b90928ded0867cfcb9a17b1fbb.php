<?php
//000000000600
 exit();?>
s:7:"waiting";