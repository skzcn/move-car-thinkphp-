<?php /*a:1:{s:48:"E:\Users\web\tp\app\index\view\login\forget.html";i:1768578390;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>找回密码 - MoveCar</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="/static/layui/css/layui.css" media="all">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4f46e5;
            --primary-hover: #4338ca;
            --bg-gradient: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }

        body {
            font-family: 'Outfit', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            background: var(--bg-gradient);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header h2 {
            font-size: 28px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 10px;
        }

        .login-header p {
            color: #64748b;
            font-size: 14px;
        }

        .layui-form-item {
            margin-bottom: 20px;
        }

        .layui-input {
            height: 48px;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            padding-left: 15px;
            transition: all 0.3s;
        }

        .layui-input:focus {
            border-color: var(--primary-color) !important;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .btn-submit {
            width: 100%;
            height: 48px;
            background: var(--primary-color) !important;
            border-radius: 12px !important;
            font-size: 16px;
            font-weight: 600;
            margin-top: 10px;
        }

        .btn-submit:hover {
            background: var(--primary-hover) !important;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #64748b;
        }

        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }

        .back-link a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .login-container {
                padding: 30px 20px;
            }

            .login-header h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="login-header">
        <h2>找回密码</h2>
        <p>请输入您的注册邮箱，我们将发送重置链接</p>
    </div>

    <form class="layui-form" action="">
        <div class="layui-form-item">
            <input type="text" name="email" lay-verify="email|required" placeholder="注册邮箱" autocomplete="off" class="layui-input">
        </div>
        
        <div class="layui-form-item">
            <button class="layui-btn btn-submit" lay-submit lay-filter="forget">发送重置邮件</button>
        </div>
    </form>

    <div class="back-link">
        <a href="<?php echo url('index/user/login'); ?>">← 返回登录</a>
    </div>
</div>

<script src="/static/layui/layui.js"></script>
<script>
layui.use(['form', 'layer', 'jquery'], function(){
    var form = layui.form;
    var layer = layui.layer;
    var $ = layui.jquery;

    // 监听提交
    form.on('submit(forget)', function(data){
        var loadIndex = layer.load(2);
        $.post("<?php echo url('sendEmail'); ?>", data.field, function(res){
            layer.close(loadIndex);
            if(res.code === 0){
                layer.msg(res.msg, {icon: 1, time: 2000}, function(){
                    // 邮件发送成功后的提示
                });
            } else {
                layer.msg(res.msg, {icon: 2});
            }
        }, 'json');
        return false;
    });
});
</script>
</body>
</html>
