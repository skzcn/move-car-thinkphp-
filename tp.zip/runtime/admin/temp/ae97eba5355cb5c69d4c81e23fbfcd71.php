<?php /*a:1:{s:47:"E:\Users\web\tp\app\admin\view\index\index.html";i:1768535560;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>后台管理系统</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="/static/layui/css/layui.css" media="all">
    <style>
        .layui-body { overflow-y: hidden; }
        .layui-tab-item { height: 100%; }
        .layui-tab-content { padding: 0; height: calc(100% - 41px); }
        iframe { width: 100%; height: 100%; border: none; }
    </style>
</head>
<body class="layui-layout-body">
<div class="layui-layout layui-layout-admin">
    <div class="layui-header">
        <div class="layui-logo">后台管理系统</div>
        <ul class="layui-nav layui-layout-right">
            <li class="layui-nav-item">
                <a href="javascript:;">
                    <?php echo htmlentities((string) $admin_name); ?>
                </a>
                <dl class="layui-nav-child">
                    <dd><a href="<?php echo url('login/logout'); ?>">退出</a></dd>
                </dl>
            </li>
        </ul>
    </div>

    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll">
            <ul class="layui-nav layui-nav-tree" lay-filter="side-menu">
                <li class="layui-nav-item layui-nav-itemed">
                    <a class="" href="javascript:;">系统管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="javascript:;" data-url="<?php echo url('user/index'); ?>" data-id="user-manage" data-title="车主管理">车主管理</a></dd>
                        <dd><a href="javascript:;" data-url="<?php echo url('ad/index'); ?>" data-id="ad-manage" data-title="广告管理">广告管理</a></dd>
                        <dd><a href="javascript:;" data-url="<?php echo url('notice/index'); ?>" data-id="notice-manage" data-title="公告管理">公告管理</a></dd>
                        <dd><a href="javascript:;" data-url="<?php echo url('admin/index'); ?>" data-id="admin-manage" data-title="管理员管理">管理员管理</a></dd>
                        <dd><a href="javascript:;" data-url="<?php echo url('system/index'); ?>" data-id="system-settings" data-title="系统设置">系统设置</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>

    <div class="layui-body">
        <div class="layui-tab" lay-filter="admin-tabs" lay-allowClose="true" style="margin: 0; height: 100%;">
            <ul class="layui-tab-title">
                <li class="layui-this" lay-id="home">控制台</li>
            </ul>
            <div class="layui-tab-content">
                <div class="layui-tab-item layui-show">
                    <div style="padding: 15px;">
                        <h2>欢迎使用后台管理系统</h2>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="layui-footer">
        © MoveCar System - 后台管理
    </div>
</div>
<script src="/static/layui/layui.js"></script>
<script>
layui.use(['element', 'jquery'], function(){
    var element = layui.element;
    var $ = layui.jquery;

    // 监听左侧菜单点击
    element.on('nav(side-menu)', function(elem){
        var url = elem.attr('data-url');
        var id = elem.attr('data-id');
        var title = elem.attr('data-title');

        if(!url || url === 'javascript:;') return;

        // 检查是否已打开
        var exists = $('.layui-tab-title li[lay-id="'+id+'"]');
        if(exists.length > 0){
            // 切换到已存在的标签
            element.tabChange('admin-tabs', id);
        } else {
            // 新增标签页
            element.tabAdd('admin-tabs', {
                title: title,
                content: '<iframe src="'+url+'" frameborder="0"></iframe>',
                id: id
            });
            element.tabChange('admin-tabs', id);
        }
    });
});
</script>
</body>
</html>
